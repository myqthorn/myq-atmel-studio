var searchData=
[
  ['nrf24l01',['nRF24L01',['../classn_r_f24_l01.html#a4392a317b65252b3d620a6c557f5f148',1,'nRF24L01::nRF24L01()'],['../classn_r_f24_l01.html#aa436e2da2244f8b76c102683272d5fa8',1,'nRF24L01::nRF24L01(uint8_t ch, uint8_t pl)']]]
];
