var searchData=
[
  ['sendcommand',['sendCommand',['../classn_r_f24_l01.html#ab91a2b186aed810bb3cb377a633bd7c9',1,'nRF24L01::sendCommand(uint8_t reg)'],['../classn_r_f24_l01.html#a8847e7e863b2c37a05bdac0f1acf4c86',1,'nRF24L01::sendCommand(uint8_t reg, uint8_t value)']]],
  ['setmode',['setMode',['../classn_r_f24_l01.html#a3f658b56f150311dc6a2836876deee06',1,'nRF24L01']]]
];
